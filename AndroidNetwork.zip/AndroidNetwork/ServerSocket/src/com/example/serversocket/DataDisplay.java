package com.example.serversocket;

public interface DataDisplay {
void Display(String message);
}
